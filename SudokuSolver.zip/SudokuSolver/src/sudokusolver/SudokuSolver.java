//Hayden M
//Suduko Solver
package sudokusolver;
import java.util.Scanner;
/**
 *
 *
 */

class Node{ //class to represent value on the board and whether it can be changed or not
    int num;
    boolean fixed = false;
    
    public Node() //default constructor
    {
        
    }
    public Node(int n)
    {
        num = n;
        if(num !=0)
        {
            fixed = true;
        }
        else
            fixed = false;
    }
    public Node(int n, boolean f)
    {
        num = n;
        fixed = f;
    }
    
    public int getNum()
    {
        return num;
    }
    public boolean getFixed()
    {
        return fixed;
    }
    
    public void setNum(int n)
    {
        num = n;
    }
    public void setFixed(boolean f)
    {
        fixed = f;
    }
}

public class SudokuSolver  extends Node{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        //input starting board values
        Node board[][] = {{new Node(0),new Node(0),new Node(1),new Node(0),new Node(3),new Node(5),new Node(0),new Node(0),new Node(0)},
                          {new Node(3),new Node(0),new Node(0),new Node(2),new Node(0),new Node(0),new Node(0),new Node(0),new Node(0)},
                          {new Node(0),new Node(0),new Node(0),new Node(7),new Node(0),new Node(1),new Node(0),new Node(0),new Node(8)},
                          {new Node(0),new Node(1),new Node(7),new Node(0),new Node(0),new Node(0),new Node(0),new Node(2),new Node(4)},
                          {new Node(0),new Node(0),new Node(8),new Node(0),new Node(0),new Node(0),new Node(9),new Node(0),new Node(0)},
                          {new Node(4),new Node(9),new Node(0),new Node(0),new Node(0),new Node(0),new Node(7),new Node(5),new Node(0)},
                          {new Node(2),new Node(0),new Node(0),new Node(5),new Node(0),new Node(6),new Node(0),new Node(0),new Node(0)},
                          {new Node(0),new Node(0),new Node(0),new Node(0),new Node(0),new Node(3),new Node(0),new Node(0),new Node(7)},
                          {new Node(0),new Node(0),new Node(0),new Node(9),new Node(4),new Node(0),new Node(3),new Node(0),new Node(0)}
        };
        
       /* Node board[][] = new Node[9][9];
        for(int i = 0; i<9; i++)
        {
            for (int j = 0; j < 9; j++) 
            {
                System.out.println("Enter board value: ");
                board[i][j] = new Node(scan.nextInt());
            }
        }
        */
        
        solvePuzzle(board);
        printBoard(board);
        
    }
    
    public static void solvePuzzle(Node n[][])
    {
        for(int i = 0;i<9;i++) //increments rows
        {
            for(int j = 0;j<9; j++) //increments columns
            {
                if(n[i][j].getFixed() == false)
                {

                    for(int k = 1;k<=9;k++) //adds number and increments if invalid number
                    {
                        n[i][j].setNum(k);
                        if(validate(n,i,j) == true)
                        {
                            break;
                        }
                        else if(validate(n,i,j) == false && k ==9)//no good, need to backtrack
                        {
                            int[] position = new int[2];
                            n[i][j].setNum(0);
                            position = backTrack(n,i,j,position); //backtrack returns position in an array
                            i= position[0];
                            j=position[1];
                        }
                    }
                }
            }
           
        }
    }
    
    public static boolean validate(Node[][]m,int r,int c){ //returns false if not valid
        for(int i = r+1; i<m.length;i++)// validate down
        {
            if(m[r][c].getNum()==m[i][c].getNum())
            {
                return false;
            }
        }
        for(int i = r-1; i>=0;i--) // validate up
        {
            if(m[r][c].getNum()==m[i][c].getNum())
            {
                return false;
            }
        }
        for(int i = c+1; i<m[r].length;i++) //validate right
        {
            if(m[r][c].getNum()==m[r][i].getNum())
            {
                return false;
            }
        }
        for(int i = c-1; i>=0;i--) //validate left
        {
            if(m[r][c].getNum()==m[r][i].getNum())
            {
                return false;
            }
        }
        //validate current quadrant by first finding the quadrant to check
        int i;
        int j;
        if(r<3)
        {
            i = 0;   
        }
        else if(r<6)
        {
            i = 3;
        }
        else
        {
            i = 6;
        }
        
        if(c<3)
        {
            j = 0;   
        }
        else if(c<6)
        {
            j = 3;
        }
        else
        {
            j = 6;
        }
        
        for(int row = i; row<i+3;row++) //checks the quadrant
        {
            for(int col = j; col<j+3; col++)
            {
                if((m[r][c].getNum()==m[row][col].getNum()) && (r!= row && c!= col))
                {
                    return false;
                }
            }
        }
        return true; //If there are no issues, return true
    }
    
    public static int[] backTrack(Node n[][], int r, int c, int[] pos)
    {
        //find last changeable number, and change it
        
        for(int i = r; i>=0; i--) //row
        {
            for(int j = c-1; j>=0; j--) //column
            {
                if(n[i][j].getFixed() == false) //if the number can be entered
                {
                    int currVal = n[i][j].getNum();
                   if(currVal == 9) //if number is already 9, we need to go ahead and keep backtracking
                   {
                       n[i][j].setNum(0);
                   }
                    for(int k = currVal+1; k<=9; k++)
                    {
                        n[i][j].setNum(k);
                        if(validate(n,i,j)==true)//if number works, progress forward from current position
                        {
                            pos[0] = i;
                            pos[1] = j;
                            return pos;
                        }
                        if((validate(n,i,j) == false && k== 9)) //backtrack again from current spot
                        {
                            n[i][j].setNum(0); //represents deleting the value when backtracking
                        }
                        
                    }
                }
                if(j == 0)
                {
                    c = n[0].length; //in case backtracking starts in the middle, gets set back to the end of previous row
                }
            }
        }
       
        pos[0] = r;
        pos[1] = c;
        return pos;
    }
    
    public static void printBoard(Node n[][]) //Prints the game board and its values
    {
        for(int i = 0;i<n.length; i++)
        {
            for (int j = 0; j < n[0].length; j++) {
                System.out.print(n[i][j].getNum() + " ");
                if(j==2 || j==5) //divides the columns into three groups
                {
                    System.out.print("| ");
                }
            }
            System.out.println("");
            if(i ==2 || i ==5) //divides the rows into three groups
            {
                System.out.println("---------------------");
            }
        }
    }
}
